import { ActivatedRouteSnapshot, CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../auth/auth.service';

export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const allowed: string[] = route.data['roles'] ?? [];

  if (auth.hasAnyRole(allowed)) return true;

  router.navigateByUrl('/forbidden');
  return false;
};
