export interface JwtUser {
  userId: number;
  email?: string;
  roles: string[];
  exp?: number;
}

function base64UrlDecode(input: string): string {
  const base64 = input.replace(/-/g, '+').replace(/_/g, '/');
  const pad = base64.length % 4;
  const padded = pad ? base64 + '='.repeat(4 - pad) : base64;

  return decodeURIComponent(
    atob(padded)
      .split('')
      .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
      .join('')
  );
}

export function parseJwt(token: string): any {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('Invalid JWT');
  return JSON.parse(base64UrlDecode(parts[1]));
}

export function mapJwtUser(token: string): JwtUser {
  const p = parseJwt(token);

  const rolesRaw = p['role'] ?? p['roles'] ?? [];
  const roles = Array.isArray(rolesRaw) ? rolesRaw : [rolesRaw];

  const userId = Number(p['nameid'] ?? p['sub'] ?? 0);

  return {
    userId,
    email: p['email'],
    roles: roles.filter(Boolean),
    exp: p['exp'],
  };
}

export function isExpired(token: string, nowSeconds = Math.floor(Date.now() / 1000)): boolean {
  const p = parseJwt(token);
  const exp = Number(p['exp'] ?? 0);
  return exp > 0 ? nowSeconds >= exp : false;
}
