import { Component } from '@angular/core';
import { AppShellComponent, AppShellNavItem } from '../../../shared/ui/app-shell/app-shell.component';

@Component({
  selector: 'app-admin-shell',
  standalone: true,
  imports: [AppShellComponent],
  templateUrl: './admin-shell.component.html',
})
export class AdminShellComponent {
  title = 'Admin Panel';

  items: AppShellNavItem[] = [
    { label: 'Anketler', icon: 'assignment', route: '/admin/surveys', exact: true },
    // ileride:
    // { label: 'Sorular', icon: 'help', route: '/admin/questions' },
    // { label: 'Cevap Şablonları', icon: 'library_books', route: '/admin/answer-templates' },
    // { label: 'Raporlar', icon: 'bar_chart', route: '/admin/reports' },
  ];
}
