import { Routes } from '@angular/router';

export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./admin-shell/admin-shell.component').then(m => m.AdminShellComponent),
    children: [
      // {
      //   path: 'surveys',
      //   loadComponent: () =>
      //     //import('./surveys/survey-list/admin-survey-list.component').then(m => m.AdminSurveyListComponent),
      // },
      { path: '', pathMatch: 'full', redirectTo: 'surveys' },
    ],
  },
];
