import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login/login.component').then(m => m.LoginComponent),
  },

  {
    path: 'user',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['User'] },
    loadChildren: () =>
      import('./features/user/user.routes').then(m => m.USER_ROUTES),
  },

  {
    path: 'admin',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['Admin'] },
    loadChildren: () =>
      import('./features/admin/admin.routes').then(m => m.ADMIN_ROUTES),
  },

  {
    path: 'forbidden',
    loadComponent: () =>
      import('./shared/ui/forbidden/forbidden.component').then(m => m.ForbiddenComponent),
  },

  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: '**', redirectTo: '' },
];
