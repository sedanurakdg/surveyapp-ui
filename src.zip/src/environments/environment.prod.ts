export const environment = {
  production: true,
  apiBaseUrl: 'https://YOUR_API',
  logLevel: 'error' as const,
};
