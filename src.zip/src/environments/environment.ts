export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:7174',
  logLevel: 'debug' as const, // 'debug' | 'info' | 'warn' | 'error' | 'none'
};